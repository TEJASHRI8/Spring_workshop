package com.example.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CollectionTable;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Transient;

@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int custId;
	private String name;
	private String email;
	private String password;
	@Transient
	private String confirmPassword;
	
	@ElementCollection(fetch = FetchType.EAGER)
	@CollectionTable(name = "phones",joinColumns = @JoinColumn(name="custId"))
	private Set<String> phoneNumbers =new HashSet<>();

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public Customer(int custId, String name, String email, String password, Set<String> phoneNumbers) {
		super();
		this.custId = custId;
		this.name = name;
		this.email = email;
		this.password = password;
		this.phoneNumbers = phoneNumbers;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public Set<String> getPhoneNumbers() {
		return phoneNumbers;
	}

	public void setPhoneNumbers(Set<String> phoneNumbers) {
		this.phoneNumbers = phoneNumbers;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", name=" + name + ", password=" + password + ", confirmPassword="
				+ confirmPassword + ", phoneNumbers=" + phoneNumbers + "]";
	}
	
	

}
